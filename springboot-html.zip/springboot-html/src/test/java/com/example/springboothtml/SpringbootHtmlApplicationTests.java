package com.example.springboothtml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootHtmlApplicationTests {

    @Test
    void contextLoads() {
    }

}
