package com.example.springboothtml.mappers;


import ch.qos.logback.core.model.Model;
import com.example.springboothtml.Repositories.registerUserRepositoryImpl;
import com.example.springboothtml.model.User;
import com.example.springboothtml.service.registerUserService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

public class loginMapper {

}
