package com.example.springboothtml.dtos;

public class requestUserDto {
}
