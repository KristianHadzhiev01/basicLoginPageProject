package com.example.springboothtml.Repositories;

import com.example.springboothtml.model.User;

import java.sql.SQLException;

public interface registerUserRepository {
    public void registerUser(User user) throws SQLException;

}
