package com.example.springboothtml.Controllers;
import com.example.springboothtml.model.User;
import com.example.springboothtml.service.loginUserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.sql.*;

@Controller
public class loginController {
loginUserService loginUserService = new loginUserService();

    @GetMapping("/login")
    public String loginPage(){
            return "loginPage";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute User user) throws SQLException {
      return loginUserService.logIn(user);
    }
}