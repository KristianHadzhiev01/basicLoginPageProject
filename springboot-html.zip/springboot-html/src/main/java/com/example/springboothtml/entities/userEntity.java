package com.example.springboothtml.entities;

public class userEntity {

}
