package com.example.springboothtml.Repositories;

import com.example.springboothtml.model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Properties;

public class loginUserRepositoryImpl implements loginUserRepository{
    public registerUserRepositoryImpl users;
    private static final String URL = "jdbc:mysql://localhost:3306/logininfodemo";
    private Connection connection;

    public registerUserRepositoryImpl getUsers() {
        return users;
    }

    public loginUserRepositoryImpl() {
        this.users = new registerUserRepositoryImpl();
    }

    public void setUsers(registerUserRepositoryImpl users) {
        this.users = users;
    }

    public Connection getConnection() {
        return connection;
    }

    public boolean logIn (User user) throws SQLException{

        Properties props = new Properties();
        props.setProperty("user","root");
        props.setProperty("password","1234");
        connection = DriverManager.getConnection(URL,props);
        ResultSet resultSet = connection.prepareStatement("SELECT * FROM userlogindata").executeQuery();

        Collection<User> allUsers = new ArrayList<>();
      while (resultSet.next()){

          User current = new User();
          String username = resultSet.getString("username");
          String password = resultSet.getString("password");
          String email = resultSet.getString("email");

          current.setUsername(username);
          current.setPassword(password);
          current.setEmail(email);
          allUsers.add(current);
      }
        users.setRegisteredUsers(allUsers);
        for (User currentUser : getUsers().getRegisteredUsers()) {
            if(currentUser.getUsername().equals(user.getUsername()) && currentUser.getPassword().equals(user.getPassword())){
                return true;
            }
        }
        return false;
    }

}
