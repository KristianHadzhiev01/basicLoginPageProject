package com.example.springboothtml.service;

import com.example.springboothtml.Repositories.loginUserRepositoryImpl;
import com.example.springboothtml.model.User;

import java.sql.SQLException;

public class loginUserService {
    private final loginUserRepositoryImpl loginUserRepository;

    public loginUserService() {
        this.loginUserRepository = new loginUserRepositoryImpl();
    }
    public String logIn(User user) throws SQLException {
        if (loginUserRepository.logIn(user)){
            return "loggedInUser";
        } else {
            return "userNotExist";
        }
    }
}
