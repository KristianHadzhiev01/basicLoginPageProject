package com.example.springboothtml.Repositories;

import com.example.springboothtml.model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Properties;

public class registerUserRepositoryImpl implements registerUserRepository {
    private Collection<User> registeredUsers;
    private static final String URL = "jdbc:mysql://localhost:3306/logininfodemo";
    private Connection connection;

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public Collection<User> getRegisteredUsers() {
        return this.registeredUsers;
    }


    public void setRegisteredUsers(Collection<User> registeredUsers) {
        this.registeredUsers = registeredUsers;
    }

    public registerUserRepositoryImpl() {
        this.registeredUsers = new ArrayList<>();
    }


    public void registerUser(User user) throws SQLException {
        Properties props = new Properties();
        props.setProperty("user", "root");
        props.setProperty("password", "1234");
        connection = DriverManager.getConnection(URL, props);

        ResultSet resultSet = connection.prepareStatement("SELECT * FROM userlogindata").executeQuery();

        Collection<User> allUsers = new ArrayList<>();
        while (resultSet.next()){

            User current = new User();
            String username = resultSet.getString("username");
            String password = resultSet.getString("password");
            String email = resultSet.getString("email");

            current.setUsername(username);
            current.setPassword(password);
            current.setEmail(email);
            allUsers.add(current);
        }
        this.setRegisteredUsers(allUsers);

        for (User registeredUser : registeredUsers) {
            if (registeredUser.getUsername().equals(user.getUsername())) {
                throw new IllegalArgumentException(String.format("User with %s username already exist!", user.getUsername()));
            }
            if (registeredUser.getEmail().equals(user.getEmail())) {
                throw new IllegalArgumentException(String.format("User with %s email address already exist!", user.getEmail()));
            }

        }
        String emailAddress = user.getEmail();
        String username = user.getUsername();
        String password = user.getPassword();

        PreparedStatement stmt = connection.prepareStatement("INSERT INTO userlogindata(username , password , email) VALUES(?,?,?)");
        stmt.setString(1, username);
        stmt.setString(2, password);
        stmt.setString(3, emailAddress);
        stmt.executeUpdate();
        this.registeredUsers.add(user);
    }

}
