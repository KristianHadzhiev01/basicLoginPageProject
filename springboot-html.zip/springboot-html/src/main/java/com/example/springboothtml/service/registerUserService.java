package com.example.springboothtml.service;

import com.example.springboothtml.Repositories.registerUserRepositoryImpl;
import com.example.springboothtml.model.User;

import java.sql.SQLException;

public class registerUserService {
    private final registerUserRepositoryImpl registerUserRepository;

    public registerUserService() {
        registerUserRepository = new registerUserRepositoryImpl();
    }

    public String registerUser(User user) {

        try {
            this.registerUserRepository.registerUser(user);
        } catch (IllegalArgumentException e) {
            System.out.println("Error!");
            return "error";

        } catch (
                SQLException e) {
            throw new RuntimeException(e);
        }
        System.out.println("Success!");

        return "userRegistered";
    }
}
