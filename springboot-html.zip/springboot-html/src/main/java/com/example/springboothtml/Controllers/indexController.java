package com.example.springboothtml.Controllers;
import com.example.springboothtml.model.User;
import com.example.springboothtml.service.registerUserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
@Controller
public class indexController {
    registerUserService registerUserService = new registerUserService();

    @GetMapping("/register")
    public String index() {
        return "index";
    }

    @PostMapping("/register")
    public String userRegistration(@ModelAttribute User user) {
        return registerUserService.registerUser(user);
    }
}
