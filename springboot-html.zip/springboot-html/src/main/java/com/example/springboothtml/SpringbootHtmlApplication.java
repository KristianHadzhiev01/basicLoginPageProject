package com.example.springboothtml;

import com.example.springboothtml.Repositories.loginUserRepositoryImpl;
import com.example.springboothtml.model.User;
import com.example.springboothtml.service.loginUserService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.sql.SQLException;

@SpringBootApplication
public class SpringbootHtmlApplication {

    public static void main(String[] args) throws SQLException {
        SpringApplication.run(SpringbootHtmlApplication.class, args);
loginUserRepositoryImpl loginUserRepository = new loginUserRepositoryImpl();
loginUserService service = new loginUserService();
        User user = new User();

        user.setUsername("pr0fex");
        user.setPassword("12345");
        user.setEmail("krisko8_fast@abv.bg");
         loginUserRepository.logIn(user);

        System.out.println(service.logIn(user));

    }
}